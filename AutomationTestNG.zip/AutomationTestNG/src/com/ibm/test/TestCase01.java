package com.ibm.test;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;


//@Listeners(com.ibm.utils.Listener.class)
public class TestCase01  {
	
	public WebDriver driver;
	
	/*public static final Logger log = Logger.getLogger(TestCase01.class.getName());

		WebElement element = null;
		public String testMethodName = null;
		
		@BeforeClass
		public void setUP(){
			
			System.out.println("#############Execution Started for Test Case 01##################");
			System.out.println(" ");
			init();
		    
		
		}
		
		@AfterClass
		public void rollOff(){
	
            System.out.println("#############Execution Completed for Test Case 01##################");
            log.info("=========== Finished Test Case01 Test=============");
            System.out.println(" ");
            driver.quit();
            driver = null;
		}
		
		 @BeforeMethod
		 public void beforeTestMethod(Method testMethod){
		   testMethodName=testMethod.getName();       
		 } */
	
	
	@Test (priority =0)
	public void testCase01_VerifyUserIsAbleToLogin() {
		
		DesiredCapabilities.internetExplorer();

		//driver.get(TestBase.getData("TestCases.Environment.URL"));
		
		
		
		String service = System.getProperty("user.dir")+"\\src\\Drivers\\geckodriver.exe";
		System.setProperty("webdriver.firefox.marionette", service);
		File pathToBinary = new File("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
		FirefoxBinary firefoxBinary = new FirefoxBinary(pathToBinary);
		FirefoxProfile firefoxProfile = new FirefoxProfile();       
		WebDriver driver = new FirefoxDriver(firefoxBinary, firefoxProfile);;
		
		
		
		
		driver.manage().window().maximize();
		
		
		//driver.manage().timeouts().implicitlyWait(Integer.parseInt(TestBase.getData("TestCases.ImplicitWait.Seconds")), TimeUnit.SECONDS);
		
		
		//driver.navigate().to("javascript:document.getElementById('overridelink').click()");
			
		driver.get("https://www.google.co.in/");
		
		WebElement element = driver.findElement(By.cssSelector("input#lst-ib"));
		
		element.sendKeys("Ritesh Mansukhani");
		
		
	
		
	
	}
	

}
